import React from 'react'
import PageLayout from '../../common/components/page-layout'

export default function AddMessage () {
  return <PageLayout title='新增留言'>
    <h1>新增留言(TODO)</h1>
  </PageLayout>
}
