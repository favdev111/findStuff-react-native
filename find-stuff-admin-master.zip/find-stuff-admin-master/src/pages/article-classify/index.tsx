import React from 'react'
import HeaderTittle from '../../common/components/header-title'

export default function AticleClassify () {
  return (
    <>
      <HeaderTittle title="添加文章" />
      <div className="p20">
        文章分类
      </div>
    </>
  )
}
