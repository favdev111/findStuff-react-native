import { Icon } from 'antd'

const BIcon = Icon.createFromIconfontCN({
  scriptUrl: '//at.alicdn.com/t/font_358841_9aw2a59f7pp.js' // 在 iconfont.cn 上生成
})

export default BIcon
