export const IS_DEV: boolean = process.env.NODE_ENV !== "production";

export const API_ROOT: string = "http://106.53.75.202:8000/auth/api/";
export const API2_ROOT: string = "http://106.53.75.202:8000/api2/";
export const ADMIN_API_ROOT: string = "http://106.53.75.202:8000/admin_api/";
export const ORIGINAL_ROOT: string = "http://106.53.75.202:8000/";

//export const API_ROOT: string = "http://localhost:8000/auth/api/";
//export const API2_ROOT: string = "http://localhost:8000/api2/";
//export const ADMIN_API_ROOT: string = "http://localhost:8000/admin_api/";
//export const ORIGINAL_ROOT: string = "http://localhost:8000/";
