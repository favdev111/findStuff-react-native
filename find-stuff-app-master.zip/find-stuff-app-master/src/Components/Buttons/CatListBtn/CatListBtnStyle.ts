import {StyleSheet, Dimensions} from 'react-native'
export default StyleSheet.create({
   CatListBtnContainer: {
      width: Dimensions.get('window').width/4,
      alignItems: 'center',
      justifyContent: 'center',
      padding: 8,
   }
})