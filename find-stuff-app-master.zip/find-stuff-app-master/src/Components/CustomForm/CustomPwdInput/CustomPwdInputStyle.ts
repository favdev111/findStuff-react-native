import {StyleSheet} from 'react-native';
export default StyleSheet.create({
  touachableButton: {
    flex: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },

  CustomTextInput: {
    flex: 7,
    alignSelf: 'stretch',
    justifyContent: 'center',
  },
});
