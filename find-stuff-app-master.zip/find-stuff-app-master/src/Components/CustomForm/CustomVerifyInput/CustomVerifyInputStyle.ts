import {StyleSheet} from 'react-native';
export default StyleSheet.create({
  CustomTextInput: {
    // backgroundColor: 'blue',
    flex: 7,
    alignSelf: 'stretch',
    justifyContent: 'center',
  },
  touachableButton: {
    // backgroundColor: 'red',
    flex: 3,
    alignSelf: 'stretch',
    justifyContent: 'center',
  },
});
