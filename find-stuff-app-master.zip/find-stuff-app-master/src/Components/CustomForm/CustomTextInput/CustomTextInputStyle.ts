import {StyleSheet} from 'react-native'
export default StyleSheet.create({
   CustomTextInput: {
      height: 40, 
      borderColor: '#ddd', 
      borderBottomWidth: 1 
   }
})