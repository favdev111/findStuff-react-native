import {StyleSheet, Dimensions} from 'react-native';
export default StyleSheet.create({
  NotificationTabContainer: {
    flex: 1,
  },
  CategoryListContainer: {
    flex: 1,
  },
});
