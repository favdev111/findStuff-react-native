# restful-api-typescript-mogodb
Restful API for a BLOG
with Nodejs, TypeScript, and MongoDB

# openssl command to generate key files

1. openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365
2. config server.ts